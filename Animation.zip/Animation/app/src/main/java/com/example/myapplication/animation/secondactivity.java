package com.example.myapplication.animation;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by Nagesh on 17/06/06.
 */
//secondactivity all ways extends fron Activity
public class secondactivity extends Activity implements Animation.AnimationListener{
    //creating two obj which are use in animation text and button
    TextView txtmsg;
    Button btn;
    //creation obj for animation
    Animation animfadein,animfadeout;

    //creating a method as oncreate
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView()...for display layout and second activity
        setContentView(R.layout.second_activity);
        // for the txt and button we created we are pointing by its id
        txtmsg =(TextView)findViewById(R.id.textView);
        btn = (Button) findViewById(R.id.button);
          animfadein = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_in);
        animfadeout=AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade_out);
        animfadein.setAnimationListener(this);
        // we have to start when the button id clicked so..
        btn.setOnClickListener(new View.OnClickListener(){
            @Override
                    public void onClick(View v){
                    txtmsg.setVisibility(View.VISIBLE);
                    txtmsg.startAnimation(animfadein);

            }


        });


    }
    //the which is implementing the interface will be need to overide this method or we can made thiss class as abstrate
    @Override
    public void onAnimationStart(Animation animation) {
        Toast.makeText(getApplicationContext(),"vishu animation started",Toast.LENGTH_LONG).show();

    }

    @Override
    public void onAnimationEnd(Animation animation) {
      // used when animation is ended
        if(animation==animfadein)
            Toast.makeText(getApplicationContext(),"vishu animation stoped",Toast.LENGTH_LONG).show();
        txtmsg.startAnimation(animfadeout);
        animfadeout.start();
        txtmsg.setVisibility(View.GONE);

    }

    @Override
    public void onAnimationRepeat(Animation animation) {

    }
}
